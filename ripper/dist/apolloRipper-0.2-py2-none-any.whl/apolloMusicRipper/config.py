DIR_UNTAGGED = "songs/untaggedSongs/"
DIR_TAGGED = "songs/taggedSongs/"
DIR_FAILED_TAG = "songs/failedTag/"


##set up pipeline
#downloader = TODO:

#list tagger options in order of preference
tagger = ["spotify"]

#post production
filters = []
